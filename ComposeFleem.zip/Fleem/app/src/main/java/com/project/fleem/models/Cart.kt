package com.project.fleem.models

data class Cart(
    val film: Film,
    val count: Int
)